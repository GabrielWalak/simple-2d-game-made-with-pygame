from Graphic import Graphics
game = Graphics()
game.run()